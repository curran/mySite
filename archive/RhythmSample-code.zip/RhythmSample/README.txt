RhythmSample is a small program which lets you play several samples at several frequencies - quarter notes, eighth notes and sixteenth notes. The GUI is written in Java using Processing as a library. The DSP is done using PureData.

In Unix, run.sh runs the whole program. It first launches PureData, then runs the Java program after waiting 2 seconds (for the PureData socket to become available).

In Windows, first open the rhythmsample.pd patch in PureData, then run the java program.

