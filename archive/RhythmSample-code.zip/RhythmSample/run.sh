#!/bin/sh
pd rhythmsample.pd &
sleep 2
java -cp bin:lib/core.jar:lib/net.jar RhythmSample

