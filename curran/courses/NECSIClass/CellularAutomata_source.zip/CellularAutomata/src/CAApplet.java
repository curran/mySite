import java.applet.Applet;
public class CAApplet extends Applet
{
	public void init()
	{
		CellularAutomata.startCellularAutomata();
	}
}