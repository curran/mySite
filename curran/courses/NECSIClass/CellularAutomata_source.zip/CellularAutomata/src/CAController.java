import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
class CAController extends JPanel{
	public CAController()
	{
		super();
		JButton stopButton = new JButton("Stop");
		stopButton.addActionListener(new ActionListener()
		{	public void actionPerformed(ActionEvent a)
			{	Parameters.stopRunningFlag = true;	}});
		add(stopButton);
		
		JFrame f = new JFrame("CA Control");
		f.setBounds(600,300,100,100);
		f.getContentPane().add(this);
		f.setVisible(true);
	}
}
