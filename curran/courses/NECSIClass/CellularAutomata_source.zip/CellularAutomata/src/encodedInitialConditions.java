
class encodedInitialConditions {
	int[][] initialConditions;
	
	public encodedInitialConditions()
	{
		initialConditions = new int[Parameters.sideCells][Parameters.sideCells];
	}
	
	public void setInitialConditions(int[][] ic)
	{
		initialConditions = ic;
	}
	
	public int[][] GetInitialConditions()
	{
		return initialConditions;
	}
}
