package utilities;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

import jyVis.graphics.DrawingPanel;
import jyVis.visualizationPrimitives.Image;

@SuppressWarnings("serial")
public class PixelPlotter extends DrawingPanel {
	Image plot;

	public PixelPlotter() {
		updateWindowOnResize = false;
		new Timer(10, new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				updateDisplay();
			}
		}).start();
	}

	public void showInFrame() {
		super.showInFrame();
		int w = getWidth();
		int h = getHeight();
		plot = new Image(w, h);
		window.setSize(w, h);
		add(plot);
	}

	/**
	 * Fills the pixel at the specified (x,y) point in coordinate space
	 * 
	 * @param x
	 * @param y
	 */
	public void plotPoint(double x, double y) {
		double pixelX = window.getXPixel(x);
		int pixelY = (int) window.getYPixel(y);
		plotPixel(pixelX, pixelY, Color.black);
	}

	public void plotPixel(double pixelX, int pixelY, Color c) {
		plot.fillPixel((int) pixelX, pixelY, c);
	}
}