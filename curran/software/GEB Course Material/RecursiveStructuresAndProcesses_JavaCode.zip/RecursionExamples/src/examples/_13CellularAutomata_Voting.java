package examples;

import java.awt.Color;

import jyVis.graphics.DrawingPanel;
import jyVis.visualizationPrimitives.Rectangle;

public class _13CellularAutomata_Voting implements Runnable {
    DrawingPanel panel = new DrawingPanel();
    int gridSize = 50;
    double rateOfEvolution = .005;
    Cell[][] cells = new Cell[gridSize][gridSize];

    public _13CellularAutomata_Voting() {
        for (int x = 0; x < gridSize; x++)
            for (int y = 0; y < gridSize; y++)
                panel.add(cells[x][y] = new Cell(x, y));
    }

    public void run() {
        while (true) {
            for (int x = 0; x < gridSize; x++)
                for (int y = 0; y < gridSize; y++) {
                    Cell my = getCell(x, y);
                    Cell[] neighboringCells = new Cell[] { getCell(x, y + 1),
                            getCell(x, y - 1), getCell(x + 1, y),
                            getCell(x - 1, y), getCell(x + 1, y + 1),
                            getCell(x + 1, y - 1), getCell(x - 1, y + 1),
                            getCell(x - 1, y - 1) };

                    double neighborhoodSum = 0;
                    for (Cell cell : neighboringCells)
                        neighborhoodSum += cell.value;

                    my.nextValue = my.value+(neighborhoodSum)*rateOfEvolution;
                }

            for (int x = 0; x < gridSize; x++)
                for (int y = 0; y < gridSize; y++) {
                    Cell c = cells[x][y];
                    c.value = c.nextValue;
                    c.color = getColor(c.value);
                }
            panel.updateDisplay();
        }
    }

    Cell getCell(int x, int y) {
        return cells[(x + gridSize) % gridSize][(y + gridSize) % gridSize];
    }

    Color getColor(double x) {
        int c = (int) ((x + 1) / 2 * 255);
        c = c > 255 ? 255 : c < 0 ? 0 : c;
        return new Color(c, c, c);
    }

    public static void main(String[] args) {
        _13CellularAutomata_Voting automata = new _13CellularAutomata_Voting();
        automata.panel.showInFrame();
        (new Thread(automata)).start();
    }

    class Cell extends Rectangle {
        double value = Math.random() * 2 - 1;

        double nextValue;

        public Cell(int x, int y) {
            super((double) x / gridSize, (double) y / gridSize,
                    (double) (x + 1) / gridSize, (double) (y + 1) / gridSize);
        }
    }
}
