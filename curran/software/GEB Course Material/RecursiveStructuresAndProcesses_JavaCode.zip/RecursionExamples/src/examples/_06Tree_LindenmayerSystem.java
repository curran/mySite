package examples;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import jyVis.graphics.DrawingPanel;
import jyVis.visualizationPrimitives.Line;

public class _06Tree_LindenmayerSystem {
    static DrawingPanel panel = new DrawingPanel();

    static double angleFactor = Math.PI / 4;
    static double sizeFactor = 0.592;
    static double trunkHeight = 0.4;
    static int depth = 0;
    static double increment, turtleX, turtleY, turtleTheta;

    static void createCurve() {
        String string = "FBR";
        for (int i = 0; i < depth; i++)
            string = string.replace("B", "-FBR++FBR-");
        
        turtleX = .5; turtleY = 0; turtleTheta = Math.PI / 2;
        increment = trunkHeight;

        if (depth < 8) // after 8 it gets too large to print
            System.out.println(string);

        for (char c : string.toCharArray())
            if (c == 'F') {
                double previousX = turtleX, previousY = turtleY;
                turtleX += Math.cos(turtleTheta) * increment;
                turtleY += Math.sin(turtleTheta) * increment;
                increment *= sizeFactor;
                panel.add(new Line(previousX, previousY, turtleX, turtleY));
            } else if (c == 'R') {
                increment /= sizeFactor;
                turtleX -= Math.cos(turtleTheta) * increment;
                turtleY -= Math.sin(turtleTheta) * increment;
            } else if (c == '+')
                turtleTheta += angleFactor;
            else if (c == '-')
                turtleTheta -= angleFactor;
    }
    public static void main(String[] args) {
        createCurve();
        panel.showInFrame();

        panel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent arg0) {
                depth += 1;
                panel.clearObjects();
                createCurve();
                panel.updateDisplay();
            }
        });
    }
}
