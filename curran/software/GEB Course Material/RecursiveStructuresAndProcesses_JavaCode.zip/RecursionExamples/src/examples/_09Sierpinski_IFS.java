package examples;

import java.util.Random;

import utilities.PixelPlotter;

public class _09Sierpinski_IFS {
    static Random randomNumberGenerator = new Random();
    static double[] xCoords = { .1, .5, .9 };
    static double[] yCoords = { .1, .9, .1 };

    public static void draw(PixelPlotter plot) {
        double x = xCoords[0], y = yCoords[0];
        while (true) {
            int next = randomNumberGenerator.nextInt(3);
            x = (x + xCoords[next]) / 2;
            y = (y + yCoords[next]) / 2;
            plot.plotPoint(x, y);
        }
    }

    public static void main(String[] args) {
        PixelPlotter plot = new PixelPlotter();
        plot.showInFrame();
        draw(plot);
    }
}