package examples;

public class _01Factorial {
    static int factorial(int n) {
        if (n > 1)
            return n * factorial(n - 1);
        else
            return 1;
    }
    public static void main(String[] args) {
        for (int i = 0; i <= 10; i++)
            System.out.println("factorial(" + i + ") = " + factorial(i));
    }
}
