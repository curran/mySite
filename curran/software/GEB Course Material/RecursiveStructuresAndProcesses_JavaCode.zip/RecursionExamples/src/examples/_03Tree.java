package examples;

import jyVis.graphics.DrawingPanel;
import jyVis.visualizationPrimitives.Line;

public class _03Tree {
    static DrawingPanel panel = new DrawingPanel();

    static double angleFactor = Math.PI / 4;
    static double sizeFactor = 0.592;
    static double trunkHeight = 0.4;
    static int depth = 12;

    public static void growTree(double x1, double y1, double rootLength,
            double rootAngle, int depth) {
        double x2 = x1 + Math.cos(rootAngle) * rootLength;
        double y2 = y1 + Math.sin(rootAngle) * rootLength;
        panel.add(new Line(x1, y1, x2, y2));

        if (depth > 0) {
            growTree(x2,y2,rootLength*sizeFactor,rootAngle+angleFactor,depth-1);
            growTree(x2,y2,rootLength*sizeFactor,rootAngle-angleFactor,depth-1);
        }
    }

    public static void main(String[] args) {
        growTree(0.5, 0, trunkHeight, Math.PI / 2, depth);
        panel.showInFrame();
    }
}
