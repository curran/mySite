package examples;

import utilities.PixelPlotter;

public class _10Fern {
    //                  maps up and spiraling
    //             maps to right branch     |
    //        maps to left branch     |     |
    //    maps to the stem|     |     |     |
    static double[] a = { 0,   .2, -.15,  .85 },
                    b = { 0, -.26,  .28,  .04 },
                    c = { 0,  .23,  .26, -.04 },
                    d = {.16, .22,  .24,  .85 },
                    f = { 0,  1.6,  .44,  1.6 },
        probabilities = {.01, .07,  .07,  .85 };
    
    public static void draw(PixelPlotter plot) {
        plot.window.set(-5, 5, -1, 10);
        double x = 0, y = 0;
        while (true) {
            int i = chooseIndex();
            x = a[i] * x + b[i] * y;
            y = c[i] * x + d[i] * y + f[i];
            plot.plotPoint(x, y);
        }
    }

    private static int chooseIndex() {
        double randomNumber = Math.random();
        double sumOfProbabilities = 0;
        int i = 0;
        for (; randomNumber >= sumOfProbabilities; i++)
            sumOfProbabilities += probabilities[i];
        return i - 1;
    }

    public static void main(String[] args) {
        PixelPlotter plot = new PixelPlotter();
        plot.showInFrame();
        draw(plot);
    }
}
