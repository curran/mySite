package examples;

import jyVis.graphics.DrawingPanel;
import jyVis.visualizationPrimitives.Line;

public class _04Koch {
    static DrawingPanel panel = new DrawingPanel();
    static int depth = 7;

    public static void createCurve(double x1, double y1, double rootLength,
            double rootAngle, int depth) {
        double unitX = Math.cos(rootAngle), unitY = Math.sin(rootAngle);
        double dx = unitX * rootLength, dy = unitY * rootLength;
        if(depth>0){//(cx,cy)
            //           *
            //          /|\
            //         / h \ 
            //        /  |  \|---d---|   
            //*-------*   *   *-------*
            //(x1,y1) (ax,ay) (bx,by) (x2,y2)
            double ax = x1 + dx * 1 / 3, ay = y1 + dy * 1 / 3;
            double bx = x1 + dx * 2 / 3, by = y1 + dy * 2 / 3;
            double d = rootLength / 3, h = Math.sqrt(3) / 2 * d;
            double cx = x1 + dx / 2 - unitY * h, cy = y1 + dy / 2 + unitX * h;

            createCurve(x1, y1, d, rootAngle, depth - 1);
            createCurve(ax, ay, d, rootAngle + Math.PI / 3, depth - 1);
            createCurve(cx, cy, d, rootAngle - Math.PI / 3, depth - 1);
            createCurve(bx, by, d, rootAngle, depth - 1);
        } else
            panel.add(new Line(x1, y1, x1 + dx, y1 + dy));
    }
    public static void main(String[] args) {
        createCurve(.01, .5, .98, 0, depth);
        panel.showInFrame();
    }
}