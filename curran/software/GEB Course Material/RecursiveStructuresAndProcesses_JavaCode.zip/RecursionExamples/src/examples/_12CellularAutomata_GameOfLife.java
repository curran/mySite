package examples;

import java.awt.Color;

import jyVis.graphics.DrawingPanel;
import jyVis.visualizationPrimitives.Rectangle;

public class _12CellularAutomata_GameOfLife implements Runnable {
    DrawingPanel panel = new DrawingPanel();
    int gridSize = 50;
    Cell[][] cells = new Cell[gridSize][gridSize];

    public _12CellularAutomata_GameOfLife() {
        for (int x = 0; x < gridSize; x++)
            for (int y = 0; y < gridSize; y++)
                panel.add(cells[x][y] = new Cell(x, y));
    }
    public void run() {
        panel.updateDisplay();
        while (true) {
            for (int x = 0; x < gridSize; x++)
                for (int y = 0; y < gridSize; y++) {
                    Cell my = getCell(x, y);
                    Cell[] neighboringCells = new Cell[] { getCell(x, y + 1),
                            getCell(x, y - 1), getCell(x + 1, y),
                            getCell(x - 1, y), getCell(x + 1, y + 1),
                            getCell(x + 1, y - 1), getCell(x - 1, y + 1),
                            getCell(x - 1, y - 1) };

                    int neighborhoodSum = 0;
                    for (Cell cell : neighboringCells)
                        neighborhoodSum += cell.value;

                    if (my.value == 1)
                        // <2, die of loneliness
                        // >3, die of overpopulation
                        if (neighborhoodSum == 2 || neighborhoodSum == 3)
                            my.nextValue = 1;
                        else
                            my.nextValue = 0;
                    else if (my.value == 0)
                        if (neighborhoodSum == 3)
                            my.nextValue = 1;
                        else
                            my.nextValue = 0;
                }

            for (int x = 0; x < gridSize; x++)
                for (int y = 0; y < gridSize; y++) {
                    Cell c = cells[x][y];
                    c.value = c.nextValue;
                    c.color = c.value == 1 ? Color.white : Color.black;
                }
            panel.updateDisplay();
        }
    }
    Cell getCell(int x, int y) {
        return cells[(x + gridSize) % gridSize][(y + gridSize) % gridSize];
    }
    public static void main(String[] args) {
        _12CellularAutomata_GameOfLife automata = new _12CellularAutomata_GameOfLife();
        automata.panel.showInFrame();
        (new Thread(automata)).start();
    }
    
    class Cell extends Rectangle {
        int value = (int) Math.round(Math.random()), nextValue;

        public Cell(int x, int y) {
            super((double) x / gridSize, (double) y / gridSize,
                    (double) (x + 1) / gridSize, (double) (y + 1) / gridSize);
        }
    }
}
