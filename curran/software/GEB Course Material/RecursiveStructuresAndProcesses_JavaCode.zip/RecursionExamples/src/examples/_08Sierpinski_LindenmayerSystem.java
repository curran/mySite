package examples;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import jyVis.graphics.DrawingPanel;
import jyVis.visualizationPrimitives.Line;

public class _08Sierpinski_LindenmayerSystem {
    static DrawingPanel panel = new DrawingPanel();

    static int depth = 0;
    static double increment, turtleX, turtleY, turtleTheta;

    static void createCurve() {
        String string = "A";
        for (int i = 0; i < depth; i++) {
            StringBuilder rewrite = new StringBuilder();
            for (char c : string.toCharArray())
                if (c == 'A')
                    rewrite.append("B-A-B");
                else if (c == 'B')
                    rewrite.append("A+B+A");
                else
                    rewrite.append(c);
            string = rewrite.toString();
        }

        if (depth < 8) // the string gets really long
            System.out.println(string);

        turtleX = .1; turtleY = 0.1; turtleTheta = 0;
        increment = .8 / Math.pow(4, depth / 2);
        
        for (char c : string.toCharArray())
            if (c == 'A' || c == 'B') {
                double previousX = turtleX, previousY = turtleY;
                turtleX += Math.cos(turtleTheta) * increment;
                turtleY += Math.sin(turtleTheta) * increment;
                panel.add(new Line(previousX, previousY, turtleX, turtleY));
            } else if (c == '+')
                turtleTheta += Math.PI / 3;
            else if (c == '-')
                turtleTheta -= Math.PI / 3;
    }

    public static void main(String[] args) {
        createCurve();
        panel.showInFrame();

        panel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent arg0) {
                depth += 2;
                panel.clearObjects();
                createCurve();
                panel.updateDisplay();
            }
        });
    }
}
