package examples;

import java.awt.Color;

import utilities.PixelPlotter;

public class _11Mandelbrot {
    static PixelPlotter plot = new PixelPlotter();
    static int maxIterations = 100;
    static ComplexNumber z = new ComplexNumber();
    static ComplexNumber c = new ComplexNumber();

    public static void draw() {
        plot.window.set(-2.2, 2.2, -2, 2);

        for (int xPixel = 0; xPixel < plot.window.getWidth(); xPixel++)
            for (int yPixel = 0; yPixel < plot.window.getHeight(); yPixel++) {
                c.real = plot.window.getXValue(xPixel);
                c.imaginary = plot.window.getYValue(yPixel);
                int iterations = calculateIterations(c);
                Color c = calculateColor(iterations);
                plot.plotPixel(xPixel, yPixel, c);
            }
    }

    static int calculateIterations(ComplexNumber c) {
        z.real = z.imaginary = 0;
        int iterations = 0;
        while (circleContains(z) && iterations < maxIterations) {
            z = z.squared().plus(c);
            iterations++;
        }
        return iterations;
    }

    private static boolean circleContains(ComplexNumber z2) {
        return Math.sqrt(z.real * z.real + z.imaginary * z.imaginary) < 2;
    }

    private static Color calculateColor(int iterations) {
        if (iterations == maxIterations)
            return Color.black;
        else {
            int red = (iterations * 10) % 255;
            int green = (iterations * 12) % 255;
            int blue = (iterations * 17) % 255;
            return new Color(red, green, blue);
        }
    }

    public static void main(String[] args) {
        plot.showInFrame();
        draw();
    }
}

class ComplexNumber {
    public double real, imaginary;

    public ComplexNumber plus(ComplexNumber numberToAdd) {
        ComplexNumber result = new ComplexNumber();
        result.real = real + numberToAdd.real;
        result.imaginary = imaginary + numberToAdd.imaginary;
        return result;
    }

    public ComplexNumber squared() {
        ComplexNumber result = new ComplexNumber();
        result.real = real * real - imaginary * imaginary;
        result.imaginary = real * imaginary + imaginary * real;
        return result;
    }
}
