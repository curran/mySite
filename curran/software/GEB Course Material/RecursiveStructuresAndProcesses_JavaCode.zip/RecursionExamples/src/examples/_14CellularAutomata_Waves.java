package examples;

import java.awt.Color;

import jyVis.graphics.DrawingPanel;
import jyVis.visualizationPrimitives.JVMouseAdapter;
import jyVis.visualizationPrimitives.Rectangle;

public class _14CellularAutomata_Waves implements Runnable {
    DrawingPanel panel = new DrawingPanel();
    int gridSize = 50;
    Cell[][] cells = new Cell[gridSize][gridSize];

    public _14CellularAutomata_Waves() {
        for (int x = 0; x < gridSize; x++)
            for (int y = 0; y < gridSize; y++) {
                panel.add(cells[x][y] = new Cell(x, y));
                if (y == gridSize / 2 && x == gridSize / 2)
                    cells[x][y].height = 50;
            }
    }

    public void run() {
        panel.updateDisplay();
        while (true) {
            for (int x = 0; x < gridSize; x++)
                for (int y = 0; y < gridSize; y++) {
                    Cell my = getCell(x, y);
                    Cell[] neighboringCells = new Cell[] { getCell(x, y + 1),
                            getCell(x, y - 1), getCell(x + 1, y),
                            getCell(x - 1, y), getCell(x + 1, y + 1),
                            getCell(x + 1, y - 1), getCell(x - 1, y + 1),
                            getCell(x - 1, y - 1) };

                    double neighborhoodSum = 0;
                    for (Cell cell : neighboringCells)
                        neighborhoodSum += cell.height - my.height;
                    my.velocity += neighborhoodSum / 8;
                }

            for (int x = 0; x < gridSize; x++)
                for (int y = 0; y < gridSize; y++) {
                    Cell c = cells[x][y];
                    c.velocity *= 0.97;
                    c.height += c.velocity;
                    c.color = getColor(c.height);
                }
            panel.updateDisplay();
        }
    }

    Cell getCell(int x, int y) {
        return cells[(x + gridSize) % gridSize][(y + gridSize) % gridSize];
    }

    Color getColor(double x) {
        int c = (int) ((x + 1) / 2 * 255);
        c = c > 255 ? 255 : c < 0 ? 0 : c;
        return new Color(c, c, c);
    }

    public static void main(String[] args) {
        _14CellularAutomata_Waves automata = new _14CellularAutomata_Waves();
        automata.panel.showInFrame();
        (new Thread(automata)).start();
    }

    class Cell extends Rectangle {
        double height = 0, velocity = 0;

        public Cell(int x, int y) {
            super((double) x / gridSize, (double) y / gridSize,
                    (double) (x + 1) / gridSize, (double) (y + 1) / gridSize);
            this.addJVMouseListener(new JVMouseAdapter() {
                public void mousePressed(double x, double y) {
                    height += 15;
                }
            });
        }
    }
}
