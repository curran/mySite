package examples;

import jyVis.graphics.DrawingPanel;
import jyVis.visualizationPrimitives.Polygon;

public class _07Sierpinski {
    static DrawingPanel panel = new DrawingPanel();
    static int depth = 7;

    public static void makeTriangles(double x1, double y1, double x2,
            double y2, double x3, double y3, int depth) { //    2
        double x1_2 = (x1 + x2) / 2, y1_2 = (y1 + y2) / 2;//   / \
        double x1_3 = (x1 + x3) / 2, y1_3 = (y1 + y3) / 2;//  /   \
        double x2_3 = (x2 + x3) / 2, y2_3 = (y2 + y3) / 2;// 1-----3

        if (depth > 0) {
            makeTriangles(x1, y1, x1_2, y1_2, x1_3, y1_3, depth - 1);
            makeTriangles(x1_2, y1_2, x2, y2, x2_3, y2_3, depth - 1);
            makeTriangles(x1_3, y1_3, x2_3, y2_3, x3, y3, depth - 1);
        } else {
            double[] xPoints = { x1, x2, x3 }, yPoints = { y1, y2, y3 };
            panel.add(new Polygon(xPoints, yPoints));
        }
    }

    public static void main(String[] args) {
        makeTriangles(.1, .1, .5, .9, .9, .1, depth);
        panel.showInFrame();
    }
}