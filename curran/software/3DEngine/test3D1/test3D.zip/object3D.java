public class object3D
{
	polygon3D[] polygons;
	public object3D(polygon3D[] P)
	{
		polygons = P;
	}
	public polygon3D[] getPolygons()
	{	return polygons;	}
}