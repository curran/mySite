import java.applet.Applet;
import java.awt.event.*;
import javax.swing.*;
public class CAApplet extends Applet
{
	public void init()
	{
		JButton startButton = new JButton("Start");
		startButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent a)
			{
				CellularAutomata.startCellularAutomata();
			}
		});
		add(startButton);
	}
}