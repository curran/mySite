public class Parameters
{
	public static final int MODE_OUTPUTIMAGES = 0, MODE_RENDERONSCREEN = 1;
	public static final int MODE_GENERATESCALEPERIODDATA = 2;
	
	public static int numRuns = 5;
	public static int classNumber = 3;
	public static int numIterations = 20000;//Integer.MAX_VALUE;
	
	public static int mode = MODE_RENDERONSCREEN;
	public static int sideCells = 80;//number of cells on one side of the grid
	public static double bias = .5;//percent of cells that are initially on (==1,==white)
	public static int waitTime = 30;//ms of wait time between iteration updates on screen
	public static int runWaitTime = 1000;//ms of wait time for next run
	
	public static boolean stopRunningFlag = false;//a flag to stop the run ( is reset automatically )
	public static boolean overrideShowOnScreen = true;//in MODE_OUTPUTIMAGES, this turns on (when 'true') repainting on screen, which is usually off (false)
	
	
	public static double globalBias = 0.0;
	public static double noiseAmplitude = 0.0;
	public static double noiseBias = 0.5;
	public static double rateOfEvolution = 1.0;
	
	
	
	
	
	
	
	
	private Parameters(){}
	public static double generateInitialCellState(int i,int j)
	{
		return getRandomWithBias();
//		double result = -1;
//		if(i == 20 || j == 20)
//			result = 1;
//		
//		return result;
			
	}
	
	public static double getRandomWithBias()
	{
		double s = (Math.random()-1+bias)*2.0;
//		if(s<0)
//			s = -1;
//		else
//			s = 1;

		if(s<-1)
			s = -1;
		else if (s>1)
			s = 1;
		return s;
	}
	
	public static double applyRule(Cell currentCentralCell,Cell[] surroundingCells)
	{
		double futureState = 0;
		
		//game of life rule
//		int temp = 0;
//		for(int i=0;i<8;i++)
//		{
//			temp+=(surroundingCells[i].getState()+1)/2;//count the number of live cells
//			//System.out.println("State: "+surroundingCells[i].getState());
//		}
//		
//		if(temp == 3)
//			futureState = 1;
//		else if(temp == 2 && currentCentralCell.getState() == 1)
//			futureState = 1;
//		else
//			futureState = -1;
//			
//		return futureState;

		//"chaotic"
//		int temp = 0;
//		for(int i=0;i<8;i++)
//		{
//			temp+=(surroundingCells[i].getState()+1)/2;//count the number of live cells
//			//System.out.println("State: "+surroundingCells[i].getState());
//		}
//		
//		if (temp % 2 == 1)
//			futureState = 1;
//		else
//			futureState = -1;
//
//		return futureState;

		//class 1 & 2
//		int temp = 0;
//		for(int i=0;i<8;i++)
//		{
//			temp+=(surroundingCells[i].getState()+1)/2;//count the number of live cells
//			//System.out.println("State: "+surroundingCells[i].getState());
//		}
//		
//		if(temp < 4)
//			futureState = -1;
//		else
//			futureState = 1;
//			
//		return futureState;

		//voting
		double averageSurroundingSide = 0;
		//int goodFriend = (int)(Math.random()*7.0);
		for(int i=0;i<8;i++)
		{
			double side = surroundingCells[i].getState();
			double influenceStrength = Math.abs(side);
			averageSurroundingSide+=influenceStrength*side;

			
		}
		averageSurroundingSide/=8;
		//averageSurroundingSide = Math.sin(averageSurroundingSide/8*Math.PI);
		
		double mySide = currentCentralCell.getState();
		
		double myWillingnessToBeInfluenced = 1.0-(Math.abs(mySide)*1);//0-->1, 1-->0,-1-->0 yes
		
		//System.out.println("myWillingnessToBeInfluenced "+myWillingnessToBeInfluenced);

		mySide += averageSurroundingSide*myWillingnessToBeInfluenced*rateOfEvolution;
		
		//noise..
		mySide +=(Math.random()-1+noiseBias)*noiseAmplitude;
		
		
		//global bias
		mySide += globalBias;
		
		//to prevent stagnation...
		double max = 0.9;
		if(mySide > max)
			mySide = max;
		else if(mySide < -max)
			mySide = -max;
		
		
		return (mySide);
		

	}
}