import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;

import javax.swing.*;
class CAController extends JPanel{
	public CAController()
	{
		super();
		 
		BoxLayout layout = new BoxLayout(this,BoxLayout.Y_AXIS);
		setLayout(layout);
		
		
		//stop button
		JButton stopButton = new JButton("Stop");
		stopButton.addActionListener(new ActionListener()
		{	public void actionPerformed(ActionEvent a)
			{	Parameters.stopRunningFlag = true;	}});
		add(stopButton);
		
		//additiveBias
		JLabel additiveBiasSliderLabel = new JLabel("additive bias: "+Parameters.globalBias);
		JSlider additiveBiasSlider = new JSlider(-50,50,0);
		additiveBiasSlider.addChangeListener( new SliderListener(additiveBiasSliderLabel)
		{	public void stateChanged(ChangeEvent e)
			{	Parameters.globalBias=(double)((JSlider)e.getSource()).getValue()/400.0;
				label.setText("additive bias: " +Parameters.globalBias);
			}});
		add(additiveBiasSliderLabel);
		add(additiveBiasSlider);
		
		//noise
		JLabel noiseSliderLabel = new JLabel("noise: "+Parameters.noiseAmplitude);
		JSlider noiseSlider = new JSlider(0,100,0);
		noiseSlider.addChangeListener( new SliderListener(noiseSliderLabel)
		{	public void stateChanged(ChangeEvent e)
			{	Parameters.noiseAmplitude=(double)((JSlider)e.getSource()).getValue()/25;
				label.setText("noise: " +Parameters.noiseAmplitude);
			}});
		add(noiseSliderLabel);
		add(noiseSlider);
		
		
		//noiseBias
		JLabel noiseBiasSliderLabel = new JLabel("noiseBias: "+Parameters.noiseBias);
		JSlider noiseBiasSlider = new JSlider(0,100,50);
		noiseBiasSlider.addChangeListener( new SliderListener(noiseBiasSliderLabel)
		{	public void stateChanged(ChangeEvent e)
			{	Parameters.noiseBias=(double)((JSlider)e.getSource()).getValue()/100;
				label.setText("noiseBias: " +Parameters.noiseBias);
			}});
		add(noiseBiasSliderLabel);
		add(noiseBiasSlider);
		
		
		//rateOfEvolution
		JLabel rateOfEvolutionSliderLabel = new JLabel("rate of evolution: "+Parameters.rateOfEvolution);
		JSlider rateOfEvolutionSlider = new JSlider(0,200,25);
		rateOfEvolutionSlider.addChangeListener( new SliderListener(rateOfEvolutionSliderLabel)
		{	public void stateChanged(ChangeEvent e)
			{	Parameters.rateOfEvolution=(double)((JSlider)e.getSource()).getValue()/25;
				label.setText("rate of evolution: " +Parameters.rateOfEvolution);
			}});
		add(rateOfEvolutionSliderLabel);
		add(rateOfEvolutionSlider);
		
		
		JFrame f = new JFrame("CA Control");
		f.setBounds(600,300,200,300);
		f.getContentPane().add(this);
		f.setVisible(true);
	}
}

abstract class SliderListener implements ChangeListener
{
	JLabel label;
	public SliderListener(JLabel label){this.label=label;}
	
	public abstract void stateChanged(ChangeEvent e);
}
