import java.awt.*;
import javax.swing.*;
import java.io.*;
import javax.imageio.*;
import java.awt.image.BufferedImage;
import java.text.*;
import java.beans.XMLEncoder;
import java.beans.XMLDecoder;

class FileOperations {
	public void saveInitialConditionsTemplate()
	{
		try
		{
			int[][] initCond = new int[Parameters.sideCells][Parameters.sideCells];
			for(int i=0;i<Parameters.sideCells;i++)
				for(int j=0;j<Parameters.sideCells;j++)
					initCond[i][j] = -1;
			encodedInitialConditions EIC = new encodedInitialConditions();
            EIC.setInitialConditions(initCond);
            
            
			File outputFile = new File("C:\\Java\\CellularAutomata\\initialConditions.txt");
		
			XMLEncoder e = new XMLEncoder(
                      new BufferedOutputStream(
                          new FileOutputStream(outputFile)));
            
            e.writeObject(EIC);
	        e.close();
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	}
}
